.. _cement.utils.shell:

:mod:`cement.utils.shell`
-------------------------

.. automodule:: cement.utils.shell
    :members:   
    :private-members:
    :show-inheritance:
