.. _cement.ext.ext_configobj:

:mod:`cement.ext.ext_configobj`
-------------------------------

.. automodule:: cement.ext.ext_configobj
    :members:   
    :private-members:
    :show-inheritance:
