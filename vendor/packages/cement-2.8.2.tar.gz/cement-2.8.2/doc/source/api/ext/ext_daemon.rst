.. _cement.ext.ext_daemon:

:mod:`cement.ext.ext_daemon`
------------------------------

.. automodule:: cement.ext.ext_daemon
    :members:   
    :private-members:
    :show-inheritance:
