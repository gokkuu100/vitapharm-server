.. _cement.ext.ext_json_configobj:

:mod:`cement.ext.ext_json_configobj`
====================================

.. automodule:: cement.ext.ext_json_configobj
    :members:   
    :private-members:
    :show-inheritance:
