.. _cement.ext.ext_mustache:

:mod:`cement.ext.ext_mustache`
------------------------------

.. automodule:: cement.ext.ext_mustache
    :members:   
    :private-members:
    :show-inheritance:
