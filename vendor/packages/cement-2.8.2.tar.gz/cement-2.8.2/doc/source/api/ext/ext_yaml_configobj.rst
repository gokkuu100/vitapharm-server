.. _cement.ext.ext_yaml_configobj:

:mod:`cement.ext.ext_yaml_configobj`
====================================

.. automodule:: cement.ext.ext_yaml_configobj
    :members:   
    :private-members:
    :show-inheritance:
