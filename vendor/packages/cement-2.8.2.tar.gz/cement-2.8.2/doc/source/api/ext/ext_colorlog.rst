.. _cement.ext.ext_colorlog:

:mod:`cement.ext.ext_colorlog`
------------------------------

.. automodule:: cement.ext.ext_colorlog
    :members:   
    :private-members:
    :show-inheritance:
