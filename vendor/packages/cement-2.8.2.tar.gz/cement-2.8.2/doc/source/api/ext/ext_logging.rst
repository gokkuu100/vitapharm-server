.. _cement.ext.ext_logging:

:mod:`cement.ext.ext_logging`
------------------------------

.. automodule:: cement.ext.ext_logging
    :members:   
    :private-members:
    :show-inheritance:
