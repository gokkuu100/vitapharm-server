.. _cement.core.controller:

:mod:`cement.core.controller`
------------------------------

.. automodule:: cement.core.controller
    :members:
    :private-members:
    :show-inheritance: