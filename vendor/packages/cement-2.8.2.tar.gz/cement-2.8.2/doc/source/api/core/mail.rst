.. _cement.core.mail:

:mod:`cement.core.mail`
--------------------------

.. automodule:: cement.core.mail
    :members:
    :private-members:
    :show-inheritance:
